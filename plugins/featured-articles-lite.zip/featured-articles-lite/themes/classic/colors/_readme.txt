To create a new color variation, copy and paste the file _demo.css, rename it to what color scheme you're going to use ( ie: if it's mainly red, call it red.css ) and edit the CSS declarations inside it to correspond to the colors you want to use.

Once you create the new file it will become available for selection in wp-admin when you edit a slider ( if you called it red.css, you will find it as option in theme color selection as *red* ).
 
All files in here have as main purpose to set the colors of your slider. You can do other CSS changes but first make sure you know what you're doing. We don't recommend changing anything else other than colors when using these files.

Now go make your rainbow theme!